FILE *abreArq (char *nomeArq, int *vet, int **mat, int *tam);

FILE *fechaArq (FILE *arq);

void forcaBruta (int *v, int pos, int *tam);

void permuta(int *vetor, int inf, int sup, int *custo);

int *troca(int *vetor, int i, int j);

int **alocaMatriz( int *tam);

int  *alocaVetor(int *tam);
