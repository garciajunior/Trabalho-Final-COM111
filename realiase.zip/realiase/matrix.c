#include <stdio.h>
#include <stdlib.h>
int somaMatrix( int ** m, int  *tam)
{
	int i, j, soma = 0;
	for (i = 0; i < *tam; i++)
	{
		for (j = 0; j < *tam; j++)
		{
			soma +=m[i][j]; 
			
		}			
		
	}
	return soma;

}
int **alocaMatriz( int *tam)
{
	int **mat, i;

	mat = (int**) malloc( *tam * sizeof(int*));
	if ( !mat)
	{
		printf("Nao e possivel alocar matriz\n");
		exit(1);
	}
	for( i = 0; i < *tam;  i++)
	{
		mat[i] = (int*)malloc(*tam * sizeof(int));
		printf("Nao e possivel alocar matriz\n");
		exit(1);
	}
	return mat;
}


int main()
{
	int i,j, **mat;
	int m[4][4];
	int tam = 4;
	m= alocaMatriz(&tam);

	FILE *arq;
	arq = fopen("matrix.txt","w");
	if ( arq == NULL)
	{	
		printf("Nao foi possivel abrir arquivo\n");
		exit(1); // sai do console
	}
	for (i = 0; i < 4; i++)
	{
		for (j = 0; j < 4; j++)
		{
			mat[i][j] = (i+114)+j+2;
		}			
		
	}
	for (i = 0; i < 4; i++)
	{
		for (j = 0; j < 4; j++)
		{
			fprintf(arq, "%d\n",mat[i][j] );
			
		}			
		
	}
	fclose(arq);
	arq = fopen("matrix.txt","rt");
	for (i = 0; i < 4; i++)
	{
		for (j = 0; j < 4; j++)
		{
			fscanf(arq,"%d\n", &m[i][j]);
			
		}			
		
	}

	for (i = 0; i < 4; i++)
	{
		for (j = 0; j < 4; j++)
		{
			printf( "%d\t",m[i][j] );
			
		}
		printf("\n");	
		}		

		fclose(arq);

		printf("\nA soma eh %d", somaMatrix(m,&tam));

		return 0;
}