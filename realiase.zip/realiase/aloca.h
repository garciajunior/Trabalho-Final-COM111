int *alocaVet (int tam);

int **alocaMatriz (int tam);

int custoCaminho (int **m, int *caminho, int qtd);

