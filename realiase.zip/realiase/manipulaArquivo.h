

FILE *abreArq (char *nomeArq);

FILE *fechaArq (FILE *arq);

